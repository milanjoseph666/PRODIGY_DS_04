# Task-04: Social Media Sentiment Analysis

## Objective
Analyze and visualize sentiment patterns in social media data to understand public opinion and attitudes towards specific topics or brands.

## Dataset
We simulate a dataset (`social_media_data.csv`) containing sample tweets about a fictional brand.

## Files
- `sentiment_analysis.py`: Python script for sentiment analysis using TextBlob and visualization using matplotlib and seaborn.
- `social_media_data.csv`: Sample social media posts.
- `README.md`: This instruction file.

## Requirements
- Python 3.x
- pandas
- matplotlib
- seaborn
- textblob

## Usage
1. Install dependencies:
```
pip install pandas matplotlib seaborn textblob
python -m textblob.download_corpora
```

2. Run the analysis:
```
python sentiment_analysis.py
```
